G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.7*
G04 #@! TF.CreationDate,2025-04-10T15:48:47+02:00*
G04 #@! TF.ProjectId,Powerline-USB-C-Frontpanel,506f7765-726c-4696-9e65-2d5553422d43,0.4*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.7) date 2025-04-10 15:48:47*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10O,7.400000X4.200000*%
%ADD11C,4.000000*%
%ADD12C,3.800000*%
%ADD13O,10.000000X4.250000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H2*
X80000000Y-149500000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X80000000Y-27000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,H5*
X80000000Y-51000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H4*
X80000000Y-140000000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X80000000Y-45000000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,H6*
X80000000Y-122000000D03*
G04 #@! TD*
M02*
